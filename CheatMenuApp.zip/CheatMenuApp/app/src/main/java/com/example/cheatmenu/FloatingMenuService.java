package com.example.cheatmenu;

import android.app.*;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;
import java.util.*;

public class FloatingMenuService extends Service {

    private WindowManager wm;
    private View rootView;
    private WindowManager.LayoutParams params;
    private TextView tvActiveCount;
    private int activeCount = 0;
    private boolean isMinimized = false;

    // Категории и функции (только визуал)
    private static final String[][][] CATEGORIES = {
        {
            {"👤", "ИГРОК"},
            {"🛡️", "Режим бога"},
            {"⚡", "Спидхак x2"},
            {"🚀", "Спидхак x5"},
            {"🦘", "Супер прыжок"},
            {"❤️", "Авто-лечение"},
            {"💀", "Один удар"},
            {"🎯", "Автоприцел"},
            {"👻", "Невидимость"},
            {"🧲", "Магнит монет"},
            {"🛑", "Стоп враги"},
            {"💣", "Мега урон"},
            {"🔋", "Бесконечная мана"},
            {"🌀", "Телепорт"},
            {"📍", "Радар врагов"},
            {"💨", "Нет кулдауна"},
            {"🔄", "Быстрый уклон"},
            {"⬆️", "Двойной прыжок"},
            {"🪂", "Нет урона от падения"},
            {"💚", "Регенерация x3"},
        },
        {
            {"🔫", "ОРУЖИЕ"},
            {"∞",  "Бесконечные патроны"},
            {"🎯", "Нет разброса"},
            {"⚡", "Быстрая стрельба"},
            {"💥", "Взрывные пули"},
            {"🔥", "Огненные пули"},
            {"❄️", "Ледяные пули"},
            {"⚡", "Молния"},
            {"🗡️", "Двойной урон"},
            {"🧨", "АОЕ урон"},
            {"🔮", "Сквозной выстрел"},
            {"🪃", "Рикошет"},
            {"🌀", "Пулемётный режим"},
        },
        {
            {"🌍", "МИР"},
            {"🌙", "Ночной режим"},
            {"☀️", "Fullbright"},
            {"🕊️", "Нет гравитации"},
            {"🐢", "Замедление мира"},
            {"🚀", "Ускорение мира"},
            {"🗺️", "Открыть всю карту"},
            {"🌊", "Режим воды"},
            {"🌫️", "Выключить туман"},
            {"🌋", "Землетрясение"},
        },
        {
            {"💰", "РЕСУРСЫ"},
            {"💰", "+1000 монет"},
            {"💎", "+500 кристаллов"},
            {"⭐", "Макс. уровень"},
            {"🏆", "Все достижения"},
            {"🎰", "Авто-фарм"},
            {"🛒", "Бесплатный магазин"},
            {"💼", "Безлимит. инвентарь"},
            {"🔑", "Все ключи"},
            {"📈", "+10000 опыта"},
        },
        {
            {"🎨", "ВИЗУАЛ"},
            {"🌈", "Радужный режим"},
            {"💡", "ESP враги"},
            {"🔭", "Дальний вид"},
            {"🔍", "Зум x3"},
            {"🎆", "Частицы x10"},
            {"💻", "Матричный дождь"},
            {"🔆", "Неоновый стиль"},
            {"📐", "Каркасный режим"},
        }
    };

    private final Map<String, Boolean> states = new LinkedHashMap<>();
    private final Map<String, TextView> nameViews = new LinkedHashMap<>();
    private final Map<String, Switch> switchViews = new LinkedHashMap<>();

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());
        buildUI();
    }

    private void buildUI() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int W = (int)(getResources().getDisplayMetrics().widthPixels * 0.88f);

        // === КОРЕНЬ ===
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xF00A0A18);

        // === ШАПКА ===
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(0xFF6200EE);
        header.setPadding(20, 12, 12, 12);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView ico = new TextView(this);
        ico.setText("🎮 ");
        ico.setTextSize(18f);

        TextView titleTv = new TextView(this);
        titleTv.setText("CHEAT MENU");
        titleTv.setTextColor(0xFFFFFFFF);
        titleTv.setTextSize(14f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLetterSpacing(0.1f);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        titleTv.setLayoutParams(titleLp);

        tvActiveCount = new TextView(this);
        tvActiveCount.setText("0/55");
        tvActiveCount.setTextColor(0xFFFFD700);
        tvActiveCount.setTextSize(11f);
        tvActiveCount.setPadding(0, 0, 12, 0);

        Button btnMin = makeHeaderBtn("_", 0xFFFF9800);
        Button btnClose = makeHeaderBtn("✕", 0xFFE53935);

        btnMin.setOnClickListener(v -> toggleMinimize(root));
        btnClose.setOnClickListener(v -> stopSelf());

        header.addView(ico);
        header.addView(titleTv);
        header.addView(tvActiveCount);
        header.addView(btnMin);
        header.addView(btnClose);

        // Drag по шапке
        setupDrag(header);

        // === ТАБЫ ===
        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        tabScroll.setBackgroundColor(0xFF110E1E);
        tabScroll.setHorizontalScrollBarEnabled(false);

        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(8, 6, 8, 0);

        // Контейнер страниц
        LinearLayout pagesContainer = new LinearLayout(this);
        pagesContainer.setOrientation(LinearLayout.VERTICAL);

        // Создаём страницы для каждой категории
        List<View> pages = new ArrayList<>();
        for (int c = 0; c < CATEGORIES.length; c++) {
            String[][] cat = CATEGORIES[c];
            String catIcon = cat[0][0];
            String catName = cat[0][1];

            // Страница категории
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setPadding(12, 4, 12, 8);
            page.setVisibility(c == 0 ? View.VISIBLE : View.GONE);

            // Заголовок категории
            TextView catLabel = new TextView(this);
            catLabel.setText(catIcon + "  " + catName);
            catLabel.setTextColor(0xFFFFD700);
            catLabel.setTextSize(11f);
            catLabel.setTypeface(null, Typeface.BOLD);
            catLabel.setLetterSpacing(0.15f);
            catLabel.setPadding(4, 12, 4, 8);
            page.addView(catLabel);

            // Функции категории
            for (int f = 1; f < cat.length; f++) {
                String featIcon = cat[f][0];
                String featName = cat[f][1];
                states.put(featName, false);
                page.addView(buildFeatureRow(featIcon, featName));
            }

            pages.add(page);
            pagesContainer.addView(page);

            // Таб кнопка
            final int idx = c;
            Button tab = new Button(this);
            tab.setText(catIcon + " " + catName);
            tab.setTextSize(11f);
            tab.setTypeface(null, Typeface.BOLD);
            tab.setPadding(20, 8, 20, 8);
            tab.setBackgroundColor(c == 0 ? 0xFF311B92 : 0x00000000);
            tab.setTextColor(c == 0 ? 0xFFBB86FC : 0xFF666688);
            tab.setOnClickListener(v -> {
                for (int i = 0; i < pages.size(); i++) {
                    pages.get(i).setVisibility(i == idx ? View.VISIBLE : View.GONE);
                }
                for (int i = 0; i < tabRow.getChildCount(); i++) {
                    Button tb = (Button) tabRow.getChildAt(i);
                    tb.setBackgroundColor(i == idx ? 0xFF311B92 : 0x00000000);
                    tb.setTextColor(i == idx ? 0xFFBB86FC : 0xFF666688);
                }
            });
            tabRow.addView(tab);
        }

        tabScroll.addView(tabRow);

        // === СКРОЛЛ СПИСКА ===
        ScrollView scroll = new ScrollView(this);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 420);
        scroll.setLayoutParams(scrollLp);
        scroll.addView(pagesContainer);

        // === ФУТЕР ===
        LinearLayout footer = new LinearLayout(this);
        footer.setBackgroundColor(0xFF0D0B1A);
        footer.setPadding(16, 8, 16, 8);
        footer.setGravity(Gravity.CENTER_VERTICAL);

        TextView footerLeft = new TextView(this);
        footerLeft.setText("⚡ Только визуальный интерфейс");
        footerLeft.setTextColor(0xFF333355);
        footerLeft.setTextSize(10f);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        footerLeft.setLayoutParams(flp);

        TextView footerRight = new TextView(this);
        footerRight.setText("v1.0");
        footerRight.setTextColor(0xFF333355);
        footerRight.setTextSize(10f);

        footer.addView(footerLeft);
        footer.addView(footerRight);

        // Сборка
        root.addView(header);
        root.addView(tabScroll);
        root.addView(scroll);
        root.addView(footer);

        rootView = root;

        params = new WindowManager.LayoutParams(
            W,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = 50;

        wm.addView(rootView, params);
    }

    private View buildFeatureRow(String icon, String name) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.HORIZONTAL);
        inner.setGravity(Gravity.CENTER_VERTICAL);
        inner.setPadding(8, 10, 8, 10);

        TextView iconTv = new TextView(this);
        iconTv.setText(icon);
        iconTv.setTextSize(15f);
        iconTv.setPadding(0, 0, 14, 0);

        TextView nameTv = new TextView(this);
        nameTv.setText(name);
        nameTv.setTextColor(0xFFCCCCCC);
        nameTv.setTextSize(12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        nameTv.setLayoutParams(lp);
        nameViews.put(name, nameTv);

        Switch sw = new Switch(this);
        sw.setChecked(false);
        switchViews.put(name, sw);

        sw.setOnCheckedChangeListener((btn, checked) -> {
            states.put(name, checked);
            nameTv.setTextColor(checked ? 0xFF00FF88 : 0xFFCCCCCC);
            updateCount();
            Toast.makeText(this,
                (checked ? "✅ " : "❌ ") + name,
                Toast.LENGTH_SHORT).show();
        });

        inner.addView(iconTv);
        inner.addView(nameTv);
        inner.addView(sw);

        View div = new View(this);
        div.setBackgroundColor(0x18FFFFFF);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1);

        row.addView(inner);
        row.addView(div, divLp);
        return row;
    }

    private Button makeHeaderBtn(String text, int color) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(0xFFFFFFFF);
        btn.setTextSize(13f);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setBackgroundColor(color);
        btn.setPadding(16, 4, 16, 4);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(80, 72);
        lp.setMargins(6, 0, 0, 0);
        btn.setLayoutParams(lp);
        return btn;
    }

    private void updateCount() {
        activeCount = 0;
        for (Boolean v : states.values()) if (v) activeCount++;
        tvActiveCount.setText(activeCount + "/55");
    }

    private void toggleMinimize(LinearLayout root) {
        isMinimized = !isMinimized;
        for (int i = 1; i < root.getChildCount() - 1; i++) {
            root.getChildAt(i).setVisibility(isMinimized ? View.GONE : View.VISIBLE);
        }
    }

    private void setupDrag(View header) {
        final int[] initXY = {0, 0};
        final float[] touchXY = {0f, 0f};
        header.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initXY[0] = params.x; initXY[1] = params.y;
                    touchXY[0] = e.getRawX(); touchXY[1] = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initXY[0] + (int)(e.getRawX() - touchXY[0]);
                    params.y = initXY[1] + (int)(e.getRawY() - touchXY[1]);
                    wm.updateViewLayout(rootView, params);
                    return true;
            }
            return false;
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (rootView != null) wm.removeView(rootView);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                "cm_ch", "Cheat Menu", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, "cm_ch")
            .setContentTitle("🎮 Cheat Menu активен")
            .setContentText("Плавающее меню запущено")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build();
    }
}
