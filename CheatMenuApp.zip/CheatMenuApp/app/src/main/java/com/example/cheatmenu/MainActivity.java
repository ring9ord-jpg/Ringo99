package com.example.cheatmenu;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Строим UI программно
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(0xFF0D0D1A);
        root.setPadding(48, 48, 48, 48);

        // Логотип
        TextView logo = new TextView(this);
        logo.setText("🎮");
        logo.setTextSize(64f);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo);

        // Заголовок
        TextView title = new TextView(this);
        title.setText("CHEAT MENU");
        title.setTextColor(0xFFBB86FC);
        title.setTextSize(26f);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 8, 0, 4);
        root.addView(title);

        // Подзаголовок
        TextView sub = new TextView(this);
        sub.setText("Визуальный интерфейс v1.0");
        sub.setTextColor(0xFF555577);
        sub.setTextSize(13f);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, 48);
        root.addView(sub);

        // Кнопка запустить
        Button btnStart = new Button(this);
        btnStart.setText("▶  ЗАПУСТИТЬ МЕНЮ");
        btnStart.setTextColor(0xFFFFFFFF);
        btnStart.setTextSize(15f);
        btnStart.setTypeface(null, android.graphics.Typeface.BOLD);
        btnStart.setBackgroundColor(0xFF6200EE);
        btnStart.setPadding(40, 20, 40, 20);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
            600, LinearLayout.LayoutParams.WRAP_CONTENT);
        btnLp.setMargins(0, 0, 0, 20);
        btnStart.setLayoutParams(btnLp);
        btnStart.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                startMenu();
            } else {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, 100);
            }
        });
        root.addView(btnStart);

        // Кнопка остановить
        Button btnStop = new Button(this);
        btnStop.setText("⏹  ОСТАНОВИТЬ");
        btnStop.setTextColor(0xFFFFFFFF);
        btnStop.setTextSize(15f);
        btnStop.setBackgroundColor(0xFFB00020);
        btnStop.setPadding(40, 20, 40, 20);
        btnStop.setLayoutParams(btnLp);
        btnStop.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingMenuService.class));
            Toast.makeText(this, "Меню закрыто", Toast.LENGTH_SHORT).show();
        });
        root.addView(btnStop);

        // Подсказка
        TextView hint = new TextView(this);
        hint.setText("Нажми запустить → выдай разрешение → меню появится поверх всего");
        hint.setTextColor(0xFF333355);
        hint.setTextSize(11f);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 32, 0, 0);
        root.addView(hint);

        setContentView(root);
    }

    private void startMenu() {
        Intent i = new Intent(this, FloatingMenuService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(i);
        else
            startService(i);
        Toast.makeText(this, "✅ Меню запущено!", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 100 && Settings.canDrawOverlays(this)) startMenu();
    }
}
